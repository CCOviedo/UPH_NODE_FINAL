const express = require('express')
const app = express()
const port = 3000
const path = require('path')
//const otroRouter = require("./routes/api.js");

app.set('view engine', 'pug')
app.set('views', 'views')

app.use(express.urlencoded({extended: false}))

//Aqui van mis routers
const rutasBasicas = require("./routes/rutasBasicas")

app.use(express.static("public"))

// app.use('/foo',router)
// app.use(otroRouter)

app.use(rutasBasicas)

// app.use("/", (req,res, next)=>{
//     console.log("Hola desde express")
//     next();
// })

//router.get("/", (req,res)=>res.sendFile(path.join(__dirname, 'views', 'index.html')))


app.listen(port, ()=>console.log("Servidor levantado y corriendo"))