const express = require("express");
const router = express.Router();

const fetch = require("node-fetch")
const apiKey = '28e40b98'
const baseURL = `http://www.omdbapi.com/?apikey=${apiKey}`

router.route("/search")
.get((req,res)=>res.render("search"))
.post((req,res)=>{
    const busqueda = req.body.busqueda
    fetch(`${baseURL}&s=${busqueda}`)
    .then(data=>data.json())
    .then(data=>res.render('results', {resultados: data.Search}))
});

router.get("/detalle-pelicula/:id", (req,res)=>{
    const idPeli = req.params.id;
    fetch(`${baseURL}&i=${idPeli}`)
    .then(data=>data.json())
    .then(data=>res.render('detalle-pelicula', {data}))
});

// router.get("/", (req,res)=>res.send("Hola desde la /"))
// // router.get("/adios", (req,res)=>res.send("Adios desde la ruta /adios"))


// router.route("/adios")
// .all((req,res,next)=>{
//     console.log("Este es el metodo all de route");
//     next();
// })
// .get((req,res)=>res.send("Adios desde la ruta /adios con GET"))
// .post((req,res)=>res.send("Adios desde la ruta /adios con POST"))

// // router.get("/prueba", (req,res)=>res.render("prueba", 
// // {
// //     texto: 'Titulo para mi pagina',
// //     listado: ['Pablo',"Maria","Paula"]
// // }))

// router.get("/prueba/:nombreUsuario/:id", (req,res)=>{
//     const miID = req.params
//     console.log(miID)
//     if(miID === null){
//         res.render("error")
//     }
//     res.render("prueba", miID)
// })

// router.get("/error404", (req,res)=>{
//     res.render("error")
// })

router.get("*", (req,res)=>res.send("404"))

module.exports = router;