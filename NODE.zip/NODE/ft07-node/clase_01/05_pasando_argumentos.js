/**
 * Cuando ejecutamos un script con node, podemos necesitar configurarlo en el propio
 * lanzamiento de la ejecución. Esto lo hacemos mediante variables que almacenamos en
 * el proceso que se esta lanzando y accedemos a ellas desde nuestro código.
 */

 if(process.argv[2] === 'saluda'){
    console.log("Hola!");
 }else{
    console.log('Hola', process.argv);
 }

/**
 * Ejercicio: ¿Recuerdas las funciones matemáticas que desarrollamos antes?, pues...
 * Me parece que sabes lo que toca.
 *  1. Importamos el modulo que ya habiamos creado 
 *  2. En lugar de setear directamente las variables, las recogeremos del proceso
 *  3. Corre el script pasando los valores de a y b 
 */

 const op = require("./operaciones");
 const a = +process.argv[2]; //El + parsea la cadena a numero
 const b = +process.argv[3];

// console.log(op.suma(parseInt(process.argv[2]),parseInt(process.argv[3])));
 console.log(op.suma(a,b));
 console.log(op.resta(process.argv[2],process.argv[3]));
 console.log(op.multiplicacion(process.argv[2],process.argv[3]));
 console.log(op.division(process.argv[2],process.argv[3]));

//Si quisiera pasar por los argumento algo como a=23, para poder sacar el numero, 
//hago lo de abajo:

//  const aA = process.argv[2]
//  const parseA = aA.split('=')
//  console.log(parseA)