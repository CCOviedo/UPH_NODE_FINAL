/**
 * window en el Browser | Global en Node
 * document en el Browser | process en Node
 */

console.log('Hola node.js');
console.log(5+7)
console.log('hola Node'.toUpperCase())