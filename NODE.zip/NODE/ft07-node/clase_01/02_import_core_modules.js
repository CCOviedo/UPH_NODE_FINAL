/**
 * Importamos los primeros modulos que nos provee la API de Node
 * en este caso haremos las pruebas con el modulo File System y su metodo
 * writeFileSync
 */

 const fs = require('fs');

 fs.writeFileSync("notas.txt","Hola desde node 2");
 
 //1)
 fs.appendFileSync("notas.txt"," Ayyyyyy lmao");

 //4)
 fs.writeFile("notas2.txt","Texto con WriteFile",()=>true);
 fs.appendFileSync("notas2.txt","Texto con Append File Sync");

 //5)
 fs.writeFile("notas3.txt","Texto con WriteFile", ()=>true)
 fs.appendFile("notas3.txt","Texto con Append File", ()=>true);

 /**
  * Ejercicio: Añadir mensajes a nuestro archivo notes.js
  *     1. Usar appendFileSync para añadir el texto al ya existente
  *     2. Ejecutamos el Script
  *     3. Comprobar que se ha añadido correctamente
  *     ---------------------------------------------
  *     4. Probar a usar writeFile combinado con appendFileSync
  *     5. Probar a usar writeFile combinado con appendFile
  *     6.Probar a usar writeFile con un texto muy largo combinado con appendFileSync con un texto de una sola palabra
  */