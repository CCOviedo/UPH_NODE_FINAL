const Suma = (a,b) =>{
    return a+b;
}

const Resta = (a,b) =>{
    return a-b;
}

const Multiplicacion = (a,b) =>{
    return a*b;
}

const Division = (a,b) =>{
    return a/b;
}

module.exports = {
    suma: Suma,
    resta: Resta,
    multiplicacion: Multiplicacion,
    division: Division

}