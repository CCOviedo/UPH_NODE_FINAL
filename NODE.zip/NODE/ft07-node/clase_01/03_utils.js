const nombre = "TEST";
const apellido = "SAMPLE";


console.log("Hola desde utils");

module.exports = {
    nombre: nombre, //Se puede poner con los : o no, depende
    apellido        //de si se llaman igual o no
}