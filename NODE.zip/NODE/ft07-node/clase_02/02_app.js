/**
 * Ya tenemos nuestro servidor levntado escuchando un puerto
 * vamos a inspeccionar que nos llega en cada uno de los request
 * que se estan haciendo:
 *  1. Antes de enviar la respuesta finalizada, hagamos un console.log(req)
 *    para ver que nos llega con la peticion.
 *  2. Demasiadas cosas ¿no? Analicemos
 */