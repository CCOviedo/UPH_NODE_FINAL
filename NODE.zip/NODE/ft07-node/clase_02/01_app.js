/**
 * Vamos a crear nuestro primer servidor con Node:
 *  1. Importamos los modulos necesarios, en este caso el modulo http
 *  2. Usamos el metodo createServe del modulo http para crear una instancia en la
 *     constante servido.
 *  3. este metodo recibe un parametro, una funcion callback
 *  4. Esta callback recibe a su vez dos parametros el objeto Request y el Response
 *  5. Por ultimo levantamos el servidor dejandolo en ecucha del pueto que designemos.
 */

 const http = require('http');

 const app = http.createServer((req, res)=>{
     //console.log(req.headers, req.url, req.method);
     //res.write("<h1>Hola 1 </h1>");
     //res.setHeader('Content-Type','text/plane')
     const {url,method} = req;
     if(url === '/'){
        res.write("<h1>Hola Node </h1>");
        res.end();
     }else if(url==="/adios"){
        res.write("<h1>Adios Node </h1>");
        res.end();
     }else{
         res.write("<h1>404</h1>");
         res.end();
     }
 });
 app.listen(3000);